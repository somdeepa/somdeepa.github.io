This code was written by Anson Soderbery to accompany the paper 
“Estimating Import Supply and Demand Elasticities: Analysis and Implications.”  
All files were last updated on 12/29/15.

FOLDER CONTENTS:

	README.txt
	feen94_LIMLhybrid.do
	mata_LIMLhybrid.do
	tester.dta

DESCRIPTION:

	mata_LIMLhybrid.do -- This file initializes the mata code needed to perform the
					  constrained nonlinear LIML routine described in Soderbery (2013).
					  Should be contained in the same folder as the main file.
						

	feen94_LIMLhybrid.do -- This is the main estimation routine.  Users must specify:

			global value   = YOUR_VAL
			global quan    = YOUR_QUANT
			global good    = YOUR_AGGREGATION (NOTE: original data must store "good" as string)
			global country = YOUR_COUNTRY	    (NOTE: original data must store "country" as string)
			global time    = YOUR_YEAR
			global minyear = YOUR_FIRSTYEAR
			global DIRECTORY = ""
			global trade_data = ""

	Additionally, users need to install Stata packages "egenmore”, "xfill”, “ivreg2” and “ranktest”  
	if they have not already.  The code then cleans and transforms the supplied data in order to 
	apply the hybrid method described in Soderbery (2013).  The code is written in a general form that allows 
	users to easily adapt the estimator to their data.  Please cite the use of code as 
	follows: 
		Soderbery, Anson, “Estimating Import Supply and Demand Elasticities: Analysis and 	
		Implications,” Mimeo, Purdue University, 2013.


TESTING AND TROUBLESHOOTING:

	Included is a sample dataset consisting of three goods.  To initialize, replace globals in feen94_LIMLhybrid.do with

		global value   = "tcvalue"
		global quan    = "tcquan"
		global good    = "hs"
		global country = "tcname"
		global time    = "timeblock"
		global minyear = 1993
		global DIRECTORY = "FILL IN YOUR DIRECTORY"
		global trade_data = "tester"

	Running the code will produce the following data:


theta1		theta2		rho1		sigma1		omega		product		cons		ref	period	constrained
.50289535	-.8555613	.24173629	1.7961996	.6677927	6211330040	-.5670198	5830	15	0
-.43023185	.38957367	.99613773	1.684132	0		0101190090	-3575.7104	6021	9	1
.97285016	-.17662561	.45541007	1.9271362	9.2003956	0101100010	-.12698156	4210	6	0

	** Optionally: Removing "cap" from line 38 will result in the full details of the data manipulation and estimation to be reported by Stata.


